在最新版（INFUSE - testAdapter 分支的最新 commit） 版本中发现一个 bug

## 描述

在 INFUSE 算法配置下进行一致性检测时，遇到某些测试用例时，会有概率 crash。

注意这个问题是概率出现的，例如下图中用同样的命令运行测试用例 286176 时，前一次没有 crash，后一次就 crash 了。

![log](./log.png)

具体的测试用例即文件夹下包含的几个测试用例，运行方法都是：

将 Infuse-latest.jar 和 Bfunction.class 复制到对应测试用例的文件夹内，然后使用命令

```bash
java -jar INFUSE-latest.jar -test -rules rule.xml -bfuncs Bfunction.class -contextpool context_pool.json -incs incs.json -cct cct.txt -approach INFUSE -mg
```

crash 时的 stdout 输出，见各个用例中的 `stdout.txt` 文件，基本都是相似的。

通过 log 中的 java.util.ConcurrentModificationException 可以看出，问题可能出在 INFUSE 算法中对某个集合进行迭代时，同时对该集合进行了修改。有可能是多线程环境下并发修改了一个不支持并发操作的数据结构。